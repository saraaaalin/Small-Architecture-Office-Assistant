Structure Assistant – Installation Guide

1. Install Rhino Plugin
- Drag StructureAssistant.rhp into Rhino
- Restart Rhino if needed

2. Open Grasshopper
- Run Grasshopper in Rhino
- Open StructureAssistant.gh

3. Keep Grasshopper running

4. Open the Structure Assistant panel in Rhino

5. Select slab geometry and start using the tool